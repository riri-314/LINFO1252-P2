#include <stdio.h>
#include <string.h>

int main(){
    printf("Test: %d\n", !strlen(""));
    return 1;
}